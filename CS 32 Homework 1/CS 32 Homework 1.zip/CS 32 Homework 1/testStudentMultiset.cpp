//
//  File.cpp
//  CS 32 Hwk 1
//
//  Created by Calvin Liu on 1/20/13.
//  Copyright (c) 2013 Calvin Liu. All rights reserved.
//

//#include "StudentMultiset.h"
//
//#include <iostream>
//#include <cassert>
//#include <string>
//using namespace std;
//
//
//int main()
//{
//    StudentMultiset sms;
//    sms.add(536893893);
//    sms.add(804182525);
//    sms.add(804182525);
//    sms.add(111111111);
//    sms.add(804182525);
//    sms.add(123456789);
//    sms.add(111111111);
//    sms.add(222222222);
//    sms.add(222222222);
//    sms.add(222222222);
//    sms.add(222222222);
//    sms.add(222222222);
//    cout << sms.size() << endl;
//    sms.print();
//}
